#include <iostream>
#include <fstream>

#include "wordnet.hpp"

int main(int argc, char *argv[]){    

    WordNet wn = WordNet();

    wn.BuildWordNet("relations.txt");
    
    ifstream tasks("subclass_task3.txt");
    for (string line; getline(tasks, line); ){
        cout << line << endl;
        wn.HandleTask(line);
        cout << endl;
    }
    
    return 0;
}
