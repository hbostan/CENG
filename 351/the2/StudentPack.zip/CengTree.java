import java.util.ArrayList;

public class CengTree
{
	public CengTreeNode root;
	
	public CengTree(Integer order)
	{
		CengTreeNode.order = order;
		
		// TODO: Create an empty Tree
	}
	
	public void addGift(CengGift gift)
	{		
		// TODO: Insert Gift to Tree
	}
	
	public ArrayList<CengTreeNode> searchGift(Integer key)
	{
		// TODO: Search within whole Tree, return visited nodes.
		// Return null if not found.
		return null;
	}
	
	public void printTree()
	{
		// TODO: Print the whole tree to console
	}

	// Extra Functions
}
